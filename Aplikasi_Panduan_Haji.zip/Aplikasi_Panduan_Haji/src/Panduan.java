
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author User
 */
public class Panduan {
    public static void main(String[] args) throws IOException {
        BufferedReader dataIn = new BufferedReader(new InputStreamReader(System.in));
        Doa jenis = new Doa();
        try
        {
            System.out.println("Tuntunan Haji");
            System.out.println("============================================");
            System.out.println("1. Ihram");
            System.out.println("2. Wukuf");
            System.out.println("3. Thawaf Ifadah");
            System.out.println("4. Sa'i");
            System.out.println("5. Mabit di Muzdalifah");
            System.out.println("6. Lempar Jumroh Aqabah");
            System.out.println("7. Mabit Di Mina");
            System.out.println("8. Thawaf Wada");
            System.out.println("9. Tahallul");
            System.out.println("============================================");
            System.out.println("Silahkan pilih angka dari 1 sampai 9 ");
            jenis.pilihPanduan();   
        }
        catch (Exception e){
            e.printStackTrace();
    }
    }
}
