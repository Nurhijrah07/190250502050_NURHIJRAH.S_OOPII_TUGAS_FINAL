
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author User
 */
public class Doa {
    private String panduan;
    
    void pilihPanduan(){
        Scanner input = new Scanner (System.in);
        String pilih;
        
        for (int i = 0; i <= 10; i++) {
        pilih = input.nextLine();
        switch (pilih){
            case "1" :
                System.out.println("=====================================================");
                System.out.println("                      Ihram                          ");
                System.out.println("                                                     ");
                System.out.println("Allahumma innii uharrimu nafsii min kulli ma harramta");
                System.out.println("‘alal muhrimi farhamnii yaa arhamar raahimiin.");
                System.out.println("=====================================================");
            break;
            
             case "2" :
                System.out.println("========================================================================================");
                System.out.println("                                          Wakuf                                         ");
                System.out.println("                                                                                        ");
                System.out.println("Allahumma lakal hamdu kalladzi naqulu wa khairom mimma naqulu,");
                System.out.println("allahumma sholati wa nusuki wa mahyaya wa mamati wa ilaika ma-abi wa laka rabbi turatsi,");
                System.out.println("allahumma inni a’uzu bika min ‘azabil qobri wa waswasatis shodri wa syatatil amri,");
                System.out.println("allahumma inni a’uzu bika min syarrima taji-u bihir rihu.");
                System.out.println("========================================================================================");
            break;

            case "3" :
                System.out.println("============================================================================================");
                System.out.println("                                   Thawaf Ifadah                                            ");
                System.out.println("                                                                                            ");
                System.out.println("Allahumma inni a’udzubika minasysyakki wasysyirki wasysyiqaaqi wannifaaqi wa suu’il akhlaaqi");
                System.out.println("wa suu’il manzhari wal munqalabi fil maali wal ahli wal waladi. Allahumma innii ");
                System.out.println("as’aluka ridhaaka wal jannata wa a’udzubika min shkathika wannaar. Allahumma");
                System.out.println(" innii a’udzubika min fitnatil qabri wa a’udzubika min fitnatil mahyaa wal mamaati.");
                System.out.println("=============================================================================================");
            break;

            case "4" :
                System.out.println("============================================================================");
                System.out.println("                               Sa'i                               ");
                System.out.println("                                                                            ");
                System.out.println("Bismillaahirrahmaanirrahiim.Abda ubimaa bada Allaahu bihi warasuuluh.");
                System.out.println("innasshafaa wal marwata min sya’aaairillaah.");
                System.out.println("Famanhajjal baita awi’tamarafa laa junaaha ‘alaihi anyathawwa fa bihimaa");
                System.out.println("waman tathawwa ‘a khairan fa innallaaha syaakirun ‘aliimun.");
                System.out.println("============================================================================");
            break;

            case "5" :
                System.out.println("========================================================================");
                System.out.println("                       Mabit di Muzdalifah                          ");
                System.out.println("                                                                        ");
                System.out.println("Allohuma ina hadzihi muzdalifatu, jumi'at fiha alsinatun muhtalifatun,");
                System.out.println("tas'aluka hawa ija mutanawi 'atan faj'alni mimman da'aaka,");
                System.out.println("fastajabta lahu watawakkala 'alaika, fakaffaitahu yaa arhamarraahimiin. ");
                System.out.println("========================================================================");
            break;

            case "6" :
                System.out.println("==================================================================================");
                System.out.println("                             Lempar Jumroh Aqadah                                 ");
                System.out.println("                                                                                  ");
                System.out.println("Alhamdu lillaahi hamdan kastiiran thayyiban mubaarakan fiih.");
                System.out.println("Allahumma laa uhshii tsanaa’an ‘alaika arta kamaa atsnaita ‘alaa nafsika.");
                System.out.println("Allahumma ilaika afadhtu wa min ‘adzaabika asyfaqtu wa aqilla ‘atsaratii wastajib");
                System.out.println("da’watii wa a’thinii su’lii. Allahummaj’alhu hajjan mabruuran wa sa’yan masykuuran");
                System.out.println("==================================================================================");
            break;

            case "7" :
                System.out.println("========================================================");
                System.out.println("                        Mabit di Mina                   ");
                System.out.println("                                                        ");
                System.out.println(" Allahumma hadzaa mina famnun 'alayya bimaa mananta bihi");
                System.out.println("'ala awliyaa ika wa ahli thaa'atika.");
                System.out.println("========================================================");
            break;

            case "8" :
                System.out.println("============================================================================");
                System.out.println("                   Thawaf Wada                     ");
                System.out.println("                                                                            ");
                System.out.println("Subahaanallaahi walhamdulillaahi wa laa ilaaha illallaahu allahu akbar. ");
                System.out.println("wa laa haula wa laa quwwata illaa billaahil ‘aliyyil ‘azhiimi. Wash shalaatu ");
                System.out.println("wassalaamu’alaa rasuulillaaahi shallallaahu ‘alaihi wa sallama. Allahumma ");
                System.out.println("iimaanan bika wa tashdiqan bikitaabika wa wafaa’an bi’aadhika wattibaa’an");
                System.out.println(" li sunnati nabiyyika muhammadin shallaahu ‘alaihi wa sallama. Allahumma ");
                System.out.println(" inni as’alukal ‘afwa wal ‘aafiya wal mu’aafatan daaimata fid diini");
                System.out.println("wad dunyaa wal aakhirati wal fauza bil jannati wannajaata minannaari.");
                System.out.println("============================================================================");
            break;

            case "9" :
                System.out.println("============================================================================================");
                System.out.println("                                Tahallul                            ");
                System.out.println("                                                                                            ");
                System.out.println("sebelum : Allahummaj’al likuli sya’ratin nuuran yaumal qiyaamati");
                System.out.println("                                                                ");
                System.out.println("sesudah : ");
                System.out.println("Alhamdulillaahil ladzii qadhaa ‘annaa manaasikanaa. Allahumma zidnaa iimaanan ");
                System.out.println("wa yaqiinan wa ‘aunan waghfir lanaa wa liwaalidainaa wa lisaa’iri muslimiiina wal muslimaati");
                System.out.println("============================================================================================");
            break;
            
            case "10" :
                System.exit (0);
            break;

            default:
                System.out.println (" Please Dech, Pilih No 1 sampai 9. Wokeeee");
    }
    }
    }
}
